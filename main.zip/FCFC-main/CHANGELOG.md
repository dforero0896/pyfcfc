# FCFC Change Log

## [1.0.1] &ndash; 2022-06-26

-   Refactorized the implementation of MPI and OpenMP parallelisms.
-   Optimized MPI communications with custom structs, and fixed the deadlock due to multiple broadcasts.

